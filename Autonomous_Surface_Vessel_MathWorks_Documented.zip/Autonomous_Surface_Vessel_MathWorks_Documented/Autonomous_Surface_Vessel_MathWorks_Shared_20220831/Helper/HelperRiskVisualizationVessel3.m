classdef HelperRiskVisualizationVessel3 < matlab.System
    % This template includes the minimum set of functions required
    % to define a System object with discrete state.

    % Public, tunable properties
    properties
        
    end

    properties(DiscreteState)

    end

    % Pre-computed constants
    properties(Access = private)
        vesselFrame
        ax
        tCPA
        dCPA
        dCPACircle
        circleAngle
    end

    methods(Access = protected)
        function setupImpl(obj)
            % Perform one-time calculations, such as computing constants
            f = findall(groot,'Name','UAV Scenario Scope');
            obj.ax = f.findobj("Type", "Axes");
            obj.vesselFrame = findobj(obj.ax, type='hgtransform', tag='UAV_Scenario_Simulink_Frame_Vessel3Sailboat.BodyFrame');
        end

        function stepImpl(obj, t_CPA_s, d_CPA_m)
            % Implement algorithm. Calculate y as a function of input u and
            % discrete states.
            if ~isvalid(obj.vesselFrame)
                f = findall(groot,'Name','UAV Scenario Scope');
                obj.ax = f.findobj("Type", "Axes");
                obj.vesselFrame = findobj(obj.ax, type='hgtransform', tag='UAV_Scenario_Simulink_Frame_Vessel3Sailboat.BodyFrame');
                obj.tCPA = text(obj.vesselFrame(1), -20, 10, 0, [num2str(t_CPA_s, '%.0f') ' s'], 'FontSize', 14);
                obj.dCPA = text(obj.vesselFrame(1), -20, -10, 0, [num2str(d_CPA_m, '%.0f') ' m'], 'FontSize', 14);
                
                % Circle
                obj.circleAngle = linspace(0, 2*pi, 20);
                R = 4000/d_CPA_m;
                if R > 40
                    R = 40;
                end
                circleX = cos(obj.circleAngle) * R;
                circleY = sin(obj.circleAngle) * R;
                obj.dCPACircle = plot3(obj.vesselFrame(1), circleX, circleY, zeros(size(circleX)), 'LineWidth', 4);
            
                view(obj.ax, 0, 90);
            end
            
            if ~isempty(obj.tCPA) && isvalid(obj.tCPA)
                % Time
                obj.tCPA.String = [num2str(t_CPA_s, '%.0f') ' s'];
                % Distance
                obj.dCPA.String = [num2str(d_CPA_m, '%.0f') ' m'];
                % Circle
                R = 4000/d_CPA_m;
                if R > 40
                    R = 40;
                end
                circleX = cos(obj.circleAngle) * R;
                circleY = sin(obj.circleAngle) * R;
                obj.dCPACircle.XData = circleX;
                obj.dCPACircle.YData = circleY;                

                % Color
                obj.tCPA.Color = [0 0.5 0.25]; % Green
                obj.dCPA.Color = [0 0.5 0.25]; % Green
                obj.dCPACircle.Color = [0 0.5 0.25]; % Green
                if (t_CPA_s < 0) 
                    if abs(d_CPA_m) < 120
                        obj.tCPA.Color = [1 0 0]; % Red
                        obj.dCPA.Color = [1 0 0]; % Red
                        obj.dCPACircle.Color = [1 0 0]; % Red
                    elseif abs(d_CPA_m) < 150
                        obj.tCPA.Color = [1 0.3725 0.0667]; % Yellow
                        obj.dCPA.Color = [1 0.3725 0.0667]; % Yellow
                        obj.dCPACircle.Color = [1 0.3725 0.0667]; % Yellow
                    end
                end
                  

                % obj.dPCA.xData = ....;
            end
        end

        function resetImpl(obj)
            % Initialize / reset discrete-state properties
        end
    end
end
