% Guidance Module
R_switch_m = 5; % go to next waypoint when the along-track distance x_e is less than R_switch (m)
Delta_m = 20; % Look ahead distance (m)
kappa = 0.1; % integral gain constant Ki = kappa * Kp
